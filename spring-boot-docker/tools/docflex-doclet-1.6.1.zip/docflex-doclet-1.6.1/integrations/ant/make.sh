#!/bin/sh

ANT_HOME=/usr/local/apache-ant-1.8.2
JAVA_HOME=/usr/java/jdk1.7.0

${ANT_HOME}/bin/ant demo

sleep 10
