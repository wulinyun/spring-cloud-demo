/**
* A few Java classes to demonstrate DocFlex/Doclet capabilities and
* how it handles some of Java5 features.
*
* @prj:type demo
*/
@Author("Filigris Works")
package java5;